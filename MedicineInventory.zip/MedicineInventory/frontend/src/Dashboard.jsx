import 'bootstrap-icons/font/bootstrap-icons.css'
import { Link, Outlet } from "react-router-dom";
import './style.css'

function Dashboard()  {
    return (
        <div class="container-fluid">
            <ul class="nav mt-4" id='links'>
                <img class="mx-1" src="/Logo/logo.png" alt="Logo" width={45} height={45}/>
                <li>
                    <Link to="/inventory" class="nav-link bg-light rounded-5 align-middle" id='inv'>
                        <i class="fs-7 bi-table"></i>
                        <span class="fs-7 ms-1 d-sm-inline">INVENTORY</span>
                    </Link>
                </li>
                <li>
                    <Link to="/product"class="nav-link m-2 mt-0 bg-light rounded-5 align-middle" id='ml'>
                        <i class="fs-7 bi-list"></i>
                        <span class="fs-7 ms-1 d-none d-sm-inline">MEDICINE LIST</span>
                    </Link>
                </li>
            </ul>
            <Outlet />
        </div>
    )
}

export default Dashboard;