import React, { useEffect, useState } from 'react'
import { Link } from "react-router-dom"
import axios from 'axios'

function Items() {
    const [data, setData] = useState([])

  useEffect(()=> {
    axios.get('http://localhost:3001/getProduct')
    .then(res => {
      if(res.data.Status === "Success") {
        setData(res.data.Result);
      } else {
        alert("Error")
      }
    })
    .catch(err => console.log(err));
  }, [])

  const handleDelete = (id) => {
    axios.delete('http://localhost:3001/delete/'+id)
    .then(res => {
      if(res.data.Status === "Success") {
        window.location.reload(true);
      } else {
        alert("Error")
      }
    })
    .catch(err => console.log(err));
  }
  return (
    <div id='items'>
      <div className='my-2 py-1 rounded-2 text-dark d-flex justify-content-center bg-light border-1 border'>
          <h3 class="fw-bold">Medicine List</h3>
      </div>
      <div class='mt-3 mx-2 shadow'>
        <table className='table table-secondary'>
          <thead>
            <tr>
              <th>Item Name</th>
              <th>Quantity</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {data.map((medicinetb, index) => {
              return <tr key={index}>
                  <td class="text-left">{medicinetb.itemname}</td>
                  <td class="text-left">{medicinetb.quantity}</td>
                  <td class="text-left">
                    <Link to={`/productEdit/`+ medicinetb.id} className='btn btn-primary btn-sm me-2' id='btnEdit2'>Edit</Link>
                    <button onClick={e => handleDelete(medicinetb.id)} className='btn btn-sm btn-danger' id='btnDelete2'>Delete</button>
                  </td>
              </tr>
            })}
          </tbody>
        </table>
      </div>
    </div>
  )
}

export default Items