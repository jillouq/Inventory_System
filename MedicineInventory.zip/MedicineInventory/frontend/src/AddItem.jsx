import axios from 'axios';
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function AddItem() {
    const [data, setData] = useState({
		itemname: '',
		quantity: ''
	});
	const navigate = useNavigate()

	const handleSubmit = (event) => {
		event.preventDefault();
		const formdata = new FormData();
		formdata.append("itemname", data.itemname);
		formdata.append("quantity", data.quantity);
        axios.post('http://localhost:3001/add', formdata)
		.then(res => {
			alert('success')
			navigate('/product')
		})
		.catch(err => console.log(err));
	}
    return (
		<div id='addItem'>
			<div class="my-2 py-1 rounded-2 text-dark d-flex justify-content-center bg-light border-1 border">
				<h3 class="fw-bold">Add Item</h3>
			</div>
			<div class="d-flex justify-content-center">
				<form class="container rounded-4 bg-secondary row g-3 w-50 mt-2 shadow" onSubmit={handleSubmit}>
					<label for="inputitemname" class="form-label">Item Name</label>
					<input type="text" class="form-control mt-1 mb-2" id="inputitemname" placeholder='Enter Item Name' autoComplete='off'
					onChange={e => setData({...data, itemname: e.target.value})}/>
				
					<label for="inputquantity" class="form-label">Quantity</label>
					<input type="number" class="form-control mt-1" id="inputquantity" placeholder='Enter Quantity'
					onChange={e => setData({...data, quantity: e.target.value})}/>
					
					<button type="submit" class="btn btn-primary mb-3" id='btnCreate'>Create</button>
				</form>
			</div>
		</div>
    );
}

export default AddItem;